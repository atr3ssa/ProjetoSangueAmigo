//pacote
package sangueamigo;


public class SangueAmigo2 {

    public static void main(String[] args) {
        ConexaoDB con = new ConexaoDB();
        con.obtemConexao();
    }
}

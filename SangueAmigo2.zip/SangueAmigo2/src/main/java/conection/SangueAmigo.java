//pacote
package conection;


public class SangueAmigo {

    public static void main(String[] args) {
        ConexaoDB con = new ConexaoDB();
        con.obtemConexao();
    }
}
